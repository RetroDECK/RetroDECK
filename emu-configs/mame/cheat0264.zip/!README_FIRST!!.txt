This archive you are now viewing contains 3 files

!README_FIRST!!.txt   <--- the file you reading
cheat.txt  <--- A text file with credits and other info (WIP)
cheat.7z  <--- The cheat file, DO NOT UNPACK THIS 7Z!!!


You should NOT unzip the cheat.7z contained in this
archive, it contains over 177,000 xml/json files and it should be kept packed up.

First of all unzip the downloaded archive and copy the still packed
cheat.7z file into the directory that contains the MAME executeable
(All MAME versions apart from the non-SDL Mac OS 9/X MAME ).
For MAME OS X (not SDL-MAME OSX) the cheat.7z file should be in:-
${HOME}/Library/Application Support/MAME OS X

Read the cheat.txt file for more info.

If you spot any errors (non-working cheats or parsing errors) then
please post them in this topic:-

http://www.mamecheat.co.uk/forums/viewtopic.php?t=3263